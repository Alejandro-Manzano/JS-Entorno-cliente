let suma = 0;
for (let i = 1; i <= 10; i++) {
    suma += i;
}
alert("La suma de los números del 1 al 10 es: " + suma);
